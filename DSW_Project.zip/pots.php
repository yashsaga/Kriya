<!DOCTYPE html>
<html>
<head>
<title>Pots</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-skype {
  background: #00aff0;
  color: white;
}


</style>

</head>

<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">

    <ul class="nav navbar-nav">
      <li><a href="pots.php">Potter's Arena</a></li>
      <li><a href="sculptures.php">Wall Of Sculptures</a></li>
      <li><a href="paintings.php">Canvas Of Miracles</a></li>
    </ul>
	<a href="home1.html"button type="submit" class="btn btn-primary navbar-btn btn-sm">Home <span class="glyphicon glyphicon-home"></span></button></a>
	<a href="developers1.html" button type= "submit" class="btn btn-info navbar-btn btn-sm" onclick='Developers.html'>About Us <span class="glyphicon glyphicon-education"></span></button></a>
	<a href="contact1.html" button type="submit" class="btn btn-warning navbar-btn btn-sm">Contact Us <span class="glyphicon glyphicon-phone-alt"></span></button></a>
	<a href="report1.html" button type="submit" class="btn btn-danger navbar-btn btn-sm">Report <span class="glyphicon glyphicon-pencil"></span></button></a>	
	<form class="navbar-form navbar-right" action="#">
        <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
        </div>
	<button type="submit" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-search"></span></button>

        </form>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="register1.html"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.html"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>


<div class="jumbotron">
	<h1><center><font family="verdana">Potter's Arena</font></center></h1><br>
	<h2><center>Experience the magic of the potters of our heartland.</center></h2>	
</div>
<br>

<?php

$servername="localhost";
$username="root";
$password="";
$dbname="test";

$conn=mysqli_connect($servername,$username,$password,$dbname);

if(!$conn)
{
die ('Connection Unsuccessful and Database not attached'.mysqli_error());
}

//Using Pots Table

$sql="select * from pots";
$c=mysqli_query($conn,$sql);
$num=mysqli_num_rows($c);

if(!$c)
{
die('TABLE CANNOT BE CONNECTED'.mysqli_error());
}
?>
  
 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/1.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/2.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>


 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/3.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/4.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/5.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/6.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/7.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/8.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/9.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/10.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/11.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/12.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/13.jpeg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/14.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/15.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/16.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/17.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/18.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/19.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/20.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/21.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/22.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/23.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/24.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>

 
<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">
	
  <div class="media-left">
    <img src="Pots/25.jpg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
  <div class="media-body">
  
<h2 class="media-heading"><u><?php echo $row['pot_title'] ?></u></h2>
<h4>&nbsp&nbsp&nbsp&nbsp	Material : <?php echo $row['material'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Design : <?php echo $row['design'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Colour : <?php echo $row['colour'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	State : <?php echo $row['state_created'] ?></h4>
<h4>&nbsp&nbsp&nbsp&nbsp	Size : <?php echo $row['size'] ?></h4>  
<h4>&nbsp&nbsp&nbsp&nbsp	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?></h4>
	<a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a>

  </div>
</div>

<br>

<?php
$row=mysqli_fetch_array($c);
?>
	<div class="media">

  <div class="media-body">
  
<h2 class="media-heading" align="right"><u><?php echo $row['pot_title'] ?></u></h2>
<h4 align="right">	Material : <?php echo $row['material'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Design : <?php echo $row['design'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Colour : <?php echo $row['colour'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	State : <?php echo $row['state_created'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
<h4 align="right">	Size : <?php echo $row['size'] ?>&nbsp&nbsp&nbsp&nbsp</h4>  
<h4 align="right">	Cost : <span class="glyphicon glyphicon-gbp"></span><?php echo $row['price'] ?>&nbsp&nbsp&nbsp&nbsp</h4>
	<h1 align="right"><a href="payment.html"button type="submit" class="btn btn-primary btn-lg"> Add To Cart <span class="glyphicon glyphicon-shopping-cart"></span></button></a></h1>

  </div>

	
  <div class="media-right">
    <img src="Pots/26.jpeg" class="img-circle" class="media-object" style="width:180px" alt="1">
  </div>
</div>
<br>



<?php
mysqli_close($conn);
?>

<br><br><br>

<div class="jumbotron">
<center>
	<a href="https://www.facebook.com/yashsaga" class="fa fa-facebook"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://twitter.com/login" class="fa fa-twitter"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=u33pWd2YJtaAogODlbr4Cg" class="fa fa-google"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.youtube.com/" class="fa fa-youtube"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.instagram.com/yash_sriv19/" class="fa fa-instagram"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.skype.com/en/" class="fa fa-skype"></a>&nbsp&nbsp&nbsp&nbsp
</center>
</div>

</body>
</html>