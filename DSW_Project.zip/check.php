<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-skype {
  background: #00aff0;
  color: white;
}



body, html {
  height: 100%;
}

* {
  box-sizing: border-box;
}

.bg-image {
  /* The image used */
  background-image: url("login.png");

  /* Add the blur effect */
  filter: blur(3px);
  -webkit-filter: blur(3px);

  /* Full height */
  height: 110%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

/* Position text in the middle of the page/image */
.bg-text {
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0, 0.3); /* Black w/opacity/see-through */
  color: white;
  font-weight: bold;
  border: 3px solid #f1f1f1;
  position: absolute;
  top: 70%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2;
  width: 80%;
  padding: 20px;
  text-align: center;
}




</style>

</head>

<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">

    <ul class="nav navbar-nav">
      <li><a href="pots.php">Potter's Arena</a></li>
      <li><a href="sculptures.php">Wall Of Sculptures</a></li>
      <li><a href="paintings.php">Canvas Of Miracles</a></li>
    </ul>
	<a href="home1.html"button type="submit" class="btn btn-primary navbar-btn btn-sm">Home <span class="glyphicon glyphicon-home"></span></button></a>
	<a href="developers1.html" button type= "submit" class="btn btn-info navbar-btn btn-sm" onclick='Developers.html'>About Us <span class="glyphicon glyphicon-education"></span></button></a>
	<a href="contact1.html" button type="submit" class="btn btn-warning navbar-btn btn-sm">Contact Us <span class="glyphicon glyphicon-phone-alt"></span></button></a>
	<a href="report1.html" button type="submit" class="btn btn-danger navbar-btn btn-sm">Report <span class="glyphicon glyphicon-pencil"></span></button></a>	
	<form class="navbar-form navbar-right" action="#">
        <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
        </div>
	<button type="submit" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-search"></span></button>

        </form>

    <ul class="nav navbar-nav navbar-right">
      <li><a href="register1.html"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.html"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<br><br>

<?php

$servername="localhost";
$username="root";
$password="";
$dbname="userlogin";

$conn=mysqli_connect($servername,$username,$password,$dbname);

if(!$conn)
{
die ('Connection Unsuccessful and Database not attached'.mysqli_error());
}

$uname=$_POST['email'];
$pwd=$_POST['pwd'];

$sql="select * from t1";
$c=mysqli_query($conn,$sql);
$num=mysqli_num_rows($c);
$flag=0;
for($i=0;$i<$num;$i++)
{
	$row=mysqli_fetch_array($c);
	if(strcmp($uname,$row['email'])==0 && strcmp($pwd,$row['pass'])==0)
	{
		$flag=1;
		break;
	}
	
}

if($flag==1)
{
	echo "<h2 align='center'>You are now logged in.<br>To continue,check out our products to purchase!</h2><br>";
}

else
{
	echo "<h2 align='center'>You have entered wrong credentials.<br>Kindly go back to the login page and enter correct details to login.</h2><br>";
}


?>








<div class="jumbotron">
<center>
	<a href="https://www.facebook.com/yashsaga" class="fa fa-facebook"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://twitter.com/login" class="fa fa-twitter"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=u33pWd2YJtaAogODlbr4Cg" class="fa fa-google"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.youtube.com/" class="fa fa-youtube"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.instagram.com/yash_sriv19/" class="fa fa-instagram"></a>&nbsp&nbsp&nbsp&nbsp
	<a href="https://www.skype.com/en/" class="fa fa-skype"></a>&nbsp&nbsp&nbsp&nbsp
</center>
</div>

</body>
</html>